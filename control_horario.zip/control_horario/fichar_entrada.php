<?php
include "db.php";
$id = $_SESSION['empleado']['id'];
$fecha = date("Y-m-d");

$existe = $conn->query("SELECT * FROM fichajes WHERE empleado_id=$id AND fecha='$fecha'");
if ($existe->num_rows == 0) {

    $lat = rand(40000000,41000000)/1000000;
    $lng = rand(-4000000,-3000000)/1000000;

    $conn->query("INSERT INTO fichajes 
        (empleado_id,fecha,hora_entrada,latitud,longitud)
        VALUES ($id,'$fecha',CURTIME(),$lat,$lng)");
}

header("Location: index.php");
