<?php
include "db.php";
$id = $_SESSION['empleado']['id'];

if ($_POST) {
    $fecha = $_POST['fecha'];
    $motivo = $_POST['motivo'];
    $conn->query("INSERT INTO ausencias (empleado_id,fecha,motivo)
                  VALUES ($id,'$fecha','$motivo')");
}
?>

<form method="post">
    <h2>Justificar ausencia</h2>
    <input type="date" name="fecha" required><br>
    <textarea name="motivo" required></textarea><br>
    <button>Guardar</button>
</form>
<a href="index.php">Volver</a>
