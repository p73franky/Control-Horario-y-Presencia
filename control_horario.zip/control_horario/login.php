<?php
include "db.php";

if ($_POST) {
    $email = $_POST['email'];
    $pass = md5($_POST['password']);

    $sql = $conn->query("SELECT * FROM empleados WHERE email='$email' AND password='$pass'");
    if ($sql->num_rows == 1) {
        $_SESSION['empleado'] = $sql->fetch_assoc();
        header("Location: index.php");
    } else {
        $error = "Credenciales incorrectas";
    }
}
?>

<form method="post">
    <h2>Login</h2>
    <input name="email" placeholder="Email" required><br>
    <input name="password" type="password" placeholder="Password" required><br>
    <button>Entrar</button>
    <?= isset($error) ? $error : "" ?>
</form>
